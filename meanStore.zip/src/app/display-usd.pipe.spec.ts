import { DisplayUsdPipe } from './display-usd.pipe';

describe('DisplayUsdPipe', () => {
  it('create an instance', () => {
    const pipe = new DisplayUsdPipe();
    expect(pipe).toBeTruthy();
  });
});
